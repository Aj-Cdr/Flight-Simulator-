AFRAME.registerComponent("collide", {
    schema: {
        elementId: { type: "string", default: "ring1" }
    },

    iscolliding: function (elementId) {
        const element = document.querySelector(elementId)
        element.addEventListener("collide", () => {
            if (elementId.includes("ring")) {
                element.setAttribute("visible", false);
                this.updateScore()
                this.updateTargets()
            } else if (elementId.includes("hurdle")) {
                element.setAttribute("visible", false);
                this.updateScore()
                this.updateTargets()
            }
            else {
                this.gameOver()
            }
        })
    },

    updateScore: function () {
        const element = document.querySelector("#score")
        var count = element.getAttribute("text").value
        var score = parseInt(count)
        score += 50

        element.setAttribute("text", { value: score })
    },

    updateTargets: function () {
        var element = document.querySelector("#targets");
        var count = element.getAttribute("text").value;
        var currentTargets = parseInt(count);
        currentTargets -= 1;
        element.setAttribute("text", {
            value: currentTargets,
        });
    },

    gameOver: function () {
        var planeEl = document.querySelector("#plane_model");
        var element = document.querySelector("#game_over_text");
        element.setAttribute("visible", true);
        planeEl.setAttribute("dynamic-body", {
            mass: 1
        });

        window.location.reload()
    },

    update: function () {
        this.iscolliding(this.data.elementId)
    },

    init: function () {
        var Duration = 120
        const Timer = document.querySelector("#timer")
        this.setTimer(Duration, Timer)
    },

    setTimer: function (duration, timer) {
        setInterval(() => {
            if (duration >= 0) {
                let minutes = parseInt(duration / 60)
                let seconds = parseInt(duration % 60)

                if (minutes < 10) {
                    minutes = "0" + minutes
                }
                if (seconds < 10) {
                    seconds = "0" + seconds
                }

                timer.setAttribute("text", { value: minutes + ":" + seconds })
                duration -= 1
            } else {
                this.gameOver()
            }
        }, 2000);
    }
})